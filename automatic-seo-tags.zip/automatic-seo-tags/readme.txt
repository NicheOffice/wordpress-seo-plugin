=== Automatic SEO Tags ===
Contributors: <a href="https://codecanyon.net/user/AhmetHakan">Ahmet Hakan</a>
Donate link: <a href="https://codecanyon.net/user/AhmetHakan">Donate</a>
Tags: seo
License: Attribution-NonCommercial-NoDerivatives 4.0 International (CC BY-NC-ND 4.0)
License URI: https://creativecommons.org/licenses/by-nc-nd/4.0/
Requires at least: 3.5
Tested up to: 3.5
Stable tag: 1.0

This lightweight script automatically creates SEO tags for posts.

== Description ==

This lightweight script automatically creates SEO tags for posts.

== Installation ==


== Frequently Asked Questions ==


== Screenshots ==


== Changelog ==

= 0.1 =
- Initial Revision
